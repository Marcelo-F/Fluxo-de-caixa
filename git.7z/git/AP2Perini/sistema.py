from ControleCaixa import ControleCaixa

controle = ControleCaixa()

controle.menu()